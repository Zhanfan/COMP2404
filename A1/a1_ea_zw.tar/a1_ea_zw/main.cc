#include <iostream>

using namespace std;

#include "RecipeManager.h"


int main()
{
  RecipeManager manager;

  manager.launch();

}

