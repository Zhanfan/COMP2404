#ifndef DEFS_H
#define DEFS_H

#define MAX_RECIPES  32

#endif

